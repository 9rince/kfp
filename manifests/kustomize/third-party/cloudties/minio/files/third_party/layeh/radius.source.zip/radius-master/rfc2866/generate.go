//go:generate go run ../cmd/radius-dict-gen/main.go -package rfc2866 -output generated.go /usr/share/freeradius/dictionary.rfc2866

package rfc2866

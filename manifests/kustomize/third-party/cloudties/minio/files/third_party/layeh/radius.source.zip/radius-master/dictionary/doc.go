// Package dictionary parses FreeRADIUS dictionary files.
//
// API is currently unstable.
package dictionary

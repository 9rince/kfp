//go:generate go run ../cmd/radius-dict-gen/main.go -package rfc2865 -output generated.go /usr/share/freeradius/dictionary.rfc2865

package rfc2865

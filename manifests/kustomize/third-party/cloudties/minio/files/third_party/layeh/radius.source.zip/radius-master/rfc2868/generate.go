//go:generate go run ../cmd/radius-dict-gen/main.go -package rfc2868 -output generated.go /usr/share/freeradius/dictionary.rfc2868

package rfc2868

# UNRELEASED

FEATURES

* Add `SeekLowerBound` to allow for range scans. [[GH-24](https://github.com/hashicorp/go-immutable-radix/pull/24)]

# 1.0.0 (August 30th, 2018)

* go mod adopted

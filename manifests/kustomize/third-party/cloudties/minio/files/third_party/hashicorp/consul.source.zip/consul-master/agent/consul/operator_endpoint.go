package consul

// Operator endpoint is used to perform low-level operator tasks for Consul.
type Operator struct {
	srv *Server
}

Plugin Example
--------------

Compile the plugin itself via:

    go build -o ./plugin/greeter ./plugin/greeter_impl.go

Compile this driver via:

    go build -o basic .

You can then launch the plugin sample via:

    ./basic

// +build !consulent

package agent

// enterpriseDelegate has no functions in OSS
type enterpriseDelegate interface{}

# Proprietary License

This license is temporary while a more official one is drafted. However,
this should make it clear:

The text contents of this website are MPL 2.0 licensed.

The design contents of this website are proprietary and may not be reproduced
or reused in any way other than to run the website locally. The license for
the design is owned solely by HashiCorp, Inc.

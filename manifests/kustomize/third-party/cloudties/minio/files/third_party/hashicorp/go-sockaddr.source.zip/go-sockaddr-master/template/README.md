# sockaddr/template

sockaddr's template library.  See
the
[sockaddr/template](https://godoc.org/github.com/hashicorp/go-sockaddr/template)
docs for details on how to use this template.

package command

import (
	"os"
)

func setupWindowNotification(ch chan<- os.Signal) {
	// do nothing
}

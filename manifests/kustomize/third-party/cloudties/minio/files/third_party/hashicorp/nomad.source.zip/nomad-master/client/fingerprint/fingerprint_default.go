// +build darwin dragonfly freebsd netbsd openbsd solaris windows

package fingerprint

func initPlatformFingerprints(fps map[string]Factory) {
}
